# TCP Hole Punching example
This project contains 3 files for basic tcp hole punching between 2 client and a mediator

Steps:
1. Compile ServerMediator, ClientA, and ClientB. (javac *.java)
2. Run MediatorServer   (java MediatorServer)
3. Run ClientA          (java ClientA)
4. Run ClientB          (java ClientB)
